/* Module Script */
var [Owner] = [Owner] || {};

[Owner].[Module] = {
};