﻿/*  
Remove [Owner][Module] table
*/

DROP TABLE [dbo].[[Owner][Module]]
GO
